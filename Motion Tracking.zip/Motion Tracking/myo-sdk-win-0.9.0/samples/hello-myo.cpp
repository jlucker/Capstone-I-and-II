// Copyright (C) 2013-2014 Thalmic Labs Inc.
// Distributed under the Myo SDK license agreement. See LICENSE.txt for details.
#define _USE_MATH_DEFINES
#include <cmath>
#include <iostream>
#include <iomanip>
#include <stdexcept>
#include <string>
#include <algorithm>
#include <myo/myo.hpp>

// MouseMover is where all the magic happens
#include "MouseMover.hpp"	

//This is for mouse movement on Windows
#pragma comment(lib, "user32") // or link to the library normally, this gets it done in one file for the sample
#include <Windows.h>

// Classes that inherit from myo::DeviceListener can be used to receive events from Myo devices. DeviceListener
// provides several virtual functions for handling different kinds of events. If you do not override an event, the
// default behavior is to do nothing.
class DataCollector : public myo::DeviceListener {
public:

	DataCollector()
		: mouse()
	{
	}

	// onOrientationData() is called whenever the Myo device provides its current orientation, which is represented
	// as a unit quaternion.
	void onOrientationData(myo::Myo* myo, uint64_t timestamp, const myo::Quaternion<float>& quat)
	{
		mouse.onOrientation(quat);
	}
	void onGyroscopeData(myo::Myo* myo, uint64_t timestamp, const myo::Vector3< float > &gyro)
	{
		mouse.onGyroscope(gyro);
		std::cout << '\r';

		// Print out the change in mouse position
		float dx = mouse.dx();
		float dy = mouse.dy();
		std::cout << "dx: " << std::setw(5) << dx << "    dy: " << std::setw(5) << dy;
		std::cout << std::flush;
		moveMouse(dx, dy);
	}

	// Tell our MouseMover which way the Myo is being worn
	void onArmSync(myo::Myo* myo, uint64_t timestamp, myo::Arm arm, myo::XDirection xDirection, float rotation,
		myo::WarmupState warmupState)
	{
		mouse.setXTowardsWrist(xDirection == myo::xDirectionTowardWrist);
	}

	// Windows mouse movement code
	void moveMouse(float dx, float dy) {
		INPUT input = { 0 };
		input.type = INPUT_MOUSE;

		input.mi.dx = (LONG)dx;
		input.mi.dy = (LONG)dy;

		input.mi.dwFlags = MOUSEEVENTF_MOVE;
		SendInput(1, &input, sizeof(INPUT));
	}

	MouseMover mouse;
};
int main(int argc, char** argv)
{
	try {
		// Set up myo. See standard hello-myo.cpp
		myo::Hub hub("com.example.hello-myo");
		std::cout << "Attempting to find a Myo..." << std::endl;
		myo::Myo* myo = hub.waitForMyo(10000);
		if (!myo) {
			throw std::runtime_error("Unable to find a Myo!");
		}
		std::cout << "Connected to a Myo armband!" << std::endl << std::endl;
		DataCollector collector;
		hub.addListener(&collector);
		while (1) {
			// In each iteration of our main loop, we run the Myo event loop for a set number of milliseconds.
			// We aren't doing anything outside the loop, so this value doesn't super matter.
			hub.run(1000 / 20);
		}
		// If a standard exception occurred, we print out its message and exit.
	}
	catch (const std::exception& e) {
		std::cerr << "Error: " << e.what() << std::endl;
		std::cerr << "Press enter to continue.";
		std::cin.ignore();
		return 1;
	}
}